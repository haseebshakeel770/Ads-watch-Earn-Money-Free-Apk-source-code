package com.rewardking.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rewardking.app.Graph
import com.rewardking.app.ads.BannerAd
import com.rewardking.app.config.*
import com.rewardking.app.data.dateKey
import com.rewardking.app.data.startOfToday
import com.rewardking.app.ui.components.*
import com.rewardking.app.ui.theme.*
import com.rewardking.app.ui.vm.MainViewModel

@Composable
fun HomeScreen(vm: MainViewModel, go: (String) -> Unit) {
    val user by vm.user.collectAsState()
    val txs by vm.transactions.collectAsState()
    val claimed by vm.claimed.collectAsState()
    val todayEarn = txs.filter { it.time >= startOfToday() && it.amount > 0 }.sumOf { it.amount }
    val doneTasks = claimed.size
    val checkedIn = user.lastCheckin == dateKey()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Hello,", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(user.name.ifBlank { "King" }, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            }
            IconButton(onClick = { vm.click(); go("notifications") }) { Icon(Icons.Filled.Notifications, "Notifications", tint = Gold) }
        }
        Spacer(Modifier.height(10.dp))

        GradientCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Total Coins", color = Color.White.copy(alpha = 0.8f), modifier = Modifier.weight(1f))
                TestModeChip()
            }
            CoinText(user.coins, size = 38)
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth()) {
                StatBlock("Today's Earnings", "+$todayEarn", Modifier.weight(1f))
                StatBlock("Ads Watched", "${user.adsWatched}", Modifier.weight(1f))
                StatBlock("Streak", "${user.streak} d", Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(14.dp))

        SoftCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    SectionTitle("Daily Check-in")
                    Text(
                        if (checkedIn) "Done for today. Come back tomorrow!" else "Claim coins and grow your streak.",
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                GoldButton(if (checkedIn) "Checked" else "Check in", enabled = !checkedIn) { vm.checkIn() }
            }
        }
        Spacer(Modifier.height(14.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GradientCard(Modifier.weight(1f), GoldGradient, onClick = { vm.click(); go("earn") }) {
                Text("Earn Coins", fontWeight = FontWeight.Bold, color = Color(0xFF3A2A00))
                Text("+${AppConfig.COINS_PER_REWARDED_AD} per ad", fontSize = 12.sp, color = Color(0xFF3A2A00))
            }
            GradientCard(Modifier.weight(1f), onClick = { vm.click(); go("wheel") }) {
                Text("Lucky Wheel", fontWeight = FontWeight.Bold, color = Color.White)
                Text("${vm.spinsLeft()} spins left", fontSize = 12.sp, color = Color.White.copy(alpha = 0.8f))
            }
        }
        Spacer(Modifier.height(14.dp))

        SoftCard(Modifier.fillMaxWidth()) {
            SectionTitle("Daily Tasks")
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { doneTasks / DAILY_TASKS.size.toFloat() },
                modifier = Modifier.fillMaxWidth().height(8.dp), color = Gold,
            )
            Spacer(Modifier.height(6.dp))
            Text("$doneTasks / ${DAILY_TASKS.size} claimed today", fontSize = 12.sp)
            TextButton(onClick = { vm.click(); go("earn") }) { Text("Open tasks") }
        }
        Spacer(Modifier.height(14.dp))

        SoftCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SectionTitle("Transaction History", Modifier.weight(1f))
                TextButton(onClick = { vm.click(); go("history") }) { Text("View all") }
            }
            if (txs.isEmpty()) EmptyState("No transactions yet", "Watch an ad or spin the wheel to earn your first coins.")
            else txs.take(5).forEach { TransactionRow(it) }
        }
        Spacer(Modifier.height(12.dp))
        BannerAd(Graph.ads.bannerId())
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun StatBlock(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(label, color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
    }
}
