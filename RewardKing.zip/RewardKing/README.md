# 👑 Reward King (Demo Android App)

Kotlin + Jetpack Compose + Material 3 + MVVM. Local-only demo reward app:
coins, rewarded/banner/interstitial test ads, lucky wheel, daily tasks, demo
withdrawal requests (JazzCash / Easypaisa UI), sounds, dark/light theme.

**No backend and no admin panel.** Coins have no cash value and no real payment is
ever made. All data lives on the phone (Room + DataStore + encrypted storage).
Uninstalling the app or clearing its data erases everything.

## Features
- Animated splash + Crown/Gold-coin logo, adaptive launcher icon
- Local demo profile (mobile + password; password stored only as a salted PBKDF2 hash in EncryptedSharedPreferences)
- Home, Earn, Lucky Wheel, Withdraw, Profile (bottom navigation) + History, Notifications, Settings, Privacy Policy, Terms
- AdMob (Google official TEST IDs): rewarded (+10 coins, only inside the SDK reward callback, once per ad), banner, interstitial (min 3 min apart)
- Limits: 30 rewarded ads/day, 30 s cooldown, 3 wheel spins/day, each task claimable once per day
- Withdrawal packages 1,000–10,000 coins (demo rates), form validation, confirmation screen, Pending/Approved/Rejected demo states
- Sounds: background music + click/coin/wheel/claim/submit effects (generated, license-free), toggles in Settings

## Build the APK on GitHub (phone friendly)
**Option A – upload the ZIP as it is (like your earlier projects)**
1. Create a repo and upload `RewardKing.zip` to the repo root.
2. Add the file `build-from-zip.yml` (provided next to this ZIP) as `.github/workflows/build.yml`.
3. Open the **Actions** tab, wait for the green tick, download the `reward-king-debug-apk` artifact (it is a ZIP: extract it to get `app-debug.apk`).

**Option B – upload the extracted files**
Upload the contents of the `RewardKing` folder to the repo root (the workflow in `.github/workflows/build.yml` is already inside). Push, then open Actions.

The workflow uses Gradle 8.9 + JDK 17 directly, so no `gradlew` file is required.
Opening the project in Android Studio also works (it will create the wrapper itself).

## Going live later (read before publishing)
1. Replace the four IDs in `app/src/main/res/values/ad_config.xml` with your real AdMob IDs and set `TEST_MODE = false` in `config/AppConfig.kt`.
2. Never click your own live ads. Keep using test ads while developing.
3. Add Google's UMP consent form for EEA/UK users, and host a real Privacy Policy URL.
4. Real rewards require server-side verification (SSV). A local-only app cannot protect real money from fraud.
5. Do not publish fake payout screens as a real feature: Google Play and AdMob can reject or ban apps that imply payments that never happen. Keep the "DEMO" labels, or add a real backend first.

## Project map
- `config/AppConfig.kt` – coins, limits, wheel rewards, withdrawal packages, tasks
- `res/values/ad_config.xml` – AdMob IDs (separate configuration file)
- `data/` – Room entities/DAO, DataStore prefs, secure password store, Repository (all reward rules)
- `ads/AdsManager.kt` – rewarded / interstitial / banner
- `audio/SoundManager.kt` – music + effects
- `ui/` – theme, components, screens, navigation, ViewModels
