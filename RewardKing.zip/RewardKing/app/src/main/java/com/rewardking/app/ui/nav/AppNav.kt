package com.rewardking.app.ui.nav

import android.widget.Toast
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.rewardking.app.ui.components.RewardPopup
import com.rewardking.app.ui.components.findActivity
import com.rewardking.app.ui.screens.*
import com.rewardking.app.ui.vm.MainViewModel

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("home", "Home", Icons.Filled.Home),
    Tab("earn", "Earn", Icons.Filled.MonetizationOn),
    Tab("wheel", "Wheel", Icons.Filled.Casino),
    Tab("withdraw", "Withdraw", Icons.Filled.AccountBalanceWallet),
    Tab("profile", "Profile", Icons.Filled.Person),
)

@Composable
fun AppNav(vm: MainViewModel = viewModel()) {
    val nav = rememberNavController()
    val ctx = LocalContext.current
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val popup by vm.popup.collectAsState()

    LaunchedEffect(Unit) {
        vm.toast.collect { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show() }
    }

    fun goTab(r: String) {
        nav.navigate(r) {
            popUpTo("home") { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (tabs.any { it.route == route }) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    tabs.forEach { t ->
                        NavigationBarItem(
                            selected = route == t.route,
                            onClick = { vm.click(); goTab(t.route) },
                            icon = { Icon(t.icon, t.label) },
                            label = { Text(t.label) },
                        )
                    }
                }
            }
        },
    ) { pad ->
        NavHost(nav, startDestination = "splash", modifier = Modifier.padding(pad)) {
            composable("splash") {
                SplashScreen { loggedIn ->
                    val target = if (loggedIn) "home" else "auth"
                    nav.navigate(target) { popUpTo("splash") { inclusive = true } }
                    if (loggedIn) vm.onAppOpened()
                }
            }
            composable("auth") {
                AuthScreen(onDone = {
                    nav.navigate("home") { popUpTo("auth") { inclusive = true } }
                    vm.onAppOpened()
                })
            }
            composable("home") { HomeScreen(vm) { r -> if (tabs.any { it.route == r }) goTab(r) else nav.navigate(r) } }
            composable("earn") { EarnScreen(vm) }
            composable("wheel") { WheelScreen(vm) }
            composable("withdraw") { WithdrawScreen(vm) }
            composable("profile") {
                ProfileScreen(
                    vm,
                    go = { r -> nav.navigate(r) },
                    onLogout = { nav.navigate("auth") { popUpTo(0) } },
                )
            }
            composable("history") { HistoryScreen(vm) }
            composable("notifications") { NotificationsScreen(vm) }
            composable("settings") { SettingsScreen(vm) }
            composable("privacy") { LegalScreen("Privacy Policy", PRIVACY_TEXT) }
            composable("terms") { LegalScreen("Terms & Conditions", TERMS_TEXT) }
        }
    }

    popup?.let { p ->
        RewardPopup(p) {
            vm.dismissPopup()
            if (p.title == "Lucky Wheel") vm.maybeInterstitial(ctx.findActivity())
        }
    }
}
