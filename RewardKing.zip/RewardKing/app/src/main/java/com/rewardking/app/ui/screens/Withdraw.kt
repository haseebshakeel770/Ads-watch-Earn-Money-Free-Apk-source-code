package com.rewardking.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rewardking.app.config.*
import com.rewardking.app.data.WithdrawalEntity
import com.rewardking.app.ui.components.*
import com.rewardking.app.ui.theme.*
import com.rewardking.app.ui.vm.MainViewModel

private val mobileRegex = Regex("^03\\d{9}$")

@Composable
fun WithdrawScreen(vm: MainViewModel) {
    val user by vm.user.collectAsState()
    val list by vm.withdrawals.collectAsState()
    val done by vm.lastWithdrawal.collectAsState()

    if (done != null) {
        ConfirmationView(done!!) { vm.clearLastWithdrawal() }
        return
    }

    var method by rememberSaveable { mutableStateOf("JazzCash") }
    var selected by rememberSaveable { mutableStateOf(0) }
    var name by rememberSaveable { mutableStateOf(user.name) }
    var mobile by rememberSaveable { mutableStateOf(user.mobile) }
    var account by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val pkg = WITHDRAW_PACKAGES[selected]

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Withdraw", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(6.dp))
        DemoNote("DEMO ONLY: this app has no server and no payment system. Requests stay in a demo status on this phone and no real money is ever sent. Conversion rates are examples, not a promise of payment.")
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Your balance: ", fontSize = 14.sp)
            CoinText(user.coins, size = 20)
        }
        Spacer(Modifier.height(12.dp))

        SectionTitle("Payment method")
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("JazzCash", "Easypaisa").forEach { m ->
                FilterChip(selected = method == m, onClick = { vm.click(); method = m }, label = { Text(m) })
            }
        }
        Spacer(Modifier.height(14.dp))

        SectionTitle("Choose package")
        Spacer(Modifier.height(6.dp))
        WITHDRAW_PACKAGES.chunked(2).forEachIndexed { row, pair ->
            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                pair.forEachIndexed { col, p ->
                    val index = row * 2 + col
                    val isSel = index == selected
                    val enough = user.coins >= p.coins
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                            .background(if (isSel) Gold.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surfaceVariant)
                            .border(BorderStroke(if (isSel) 2.dp else 0.dp, Gold), RoundedCornerShape(16.dp))
                            .clickable { vm.click(); selected = index }.padding(12.dp),
                    ) {
                        Text("${"%,d".format(p.coins)} coins", fontWeight = FontWeight.Bold)
                        Text("PKR ${"%,d".format(p.pkr)}", color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                        if (!enough) Text("Not enough coins", fontSize = 10.sp, color = MaterialTheme.colorScheme.error)
                    }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(10.dp))

        SectionTitle("Account details")
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(name, { name = it }, label = { Text("Full name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            mobile, { mobile = it.filter { c -> c.isDigit() }.take(11) }, label = { Text("Mobile number") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            account, { account = it.filter { c -> c.isDigit() }.take(11) }, label = { Text("$method account number") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth()) {
            Text("Coins required: ${"%,d".format(pkg.coins)}", Modifier.weight(1f), fontSize = 13.sp)
            Text("Amount: PKR ${"%,d".format(pkg.pkr)}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        error?.let { Spacer(Modifier.height(6.dp)); Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
        Spacer(Modifier.height(12.dp))
        GoldButton("Submit Demo Request", Modifier.fillMaxWidth()) {
            error = when {
                name.trim().length < 3 -> "Enter your full name."
                !mobileRegex.matches(mobile) -> "Mobile number must look like 03XXXXXXXXX."
                !mobileRegex.matches(account) -> "Account number must look like 03XXXXXXXXX."
                user.coins < pkg.coins -> "You need ${pkg.coins - user.coins} more coins for this package."
                else -> null
            }
            if (error == null) vm.submitWithdrawal(method, name, mobile, account, pkg)
        }

        Spacer(Modifier.height(20.dp))
        SectionTitle("Your requests")
        Spacer(Modifier.height(6.dp))
        if (list.isEmpty()) EmptyState("No requests yet", "Submitted demo requests will appear here.")
        list.forEach { w -> RequestCard(w, vm) }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun RequestCard(w: WithdrawalEntity, vm: MainViewModel) {
    SoftCard(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("${w.method} • PKR ${"%,d".format(w.pkr)}", fontWeight = FontWeight.Bold)
                Text("${"%,d".format(w.coins)} coins • ${formatTime(w.time)}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            StatusChip(w.status)
        }
        if (w.status == "PENDING") {
            Row {
                TextButton(onClick = { vm.demoStatus(w, "APPROVED") }) { Text("Demo: Approve", fontSize = 12.sp) }
                TextButton(onClick = { vm.demoStatus(w, "REJECTED") }) { Text("Demo: Reject (refund)", fontSize = 12.sp) }
            }
        }
    }
}

@Composable
fun StatusChip(status: String) {
    val (label, color) = when (status) {
        "APPROVED" -> "Approved (demo)" to Green
        "REJECTED" -> "Rejected (demo)" to Red
        else -> "Pending (demo)" to Color(0xFFEF6C00)
    }
    Text(
        label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(color).padding(horizontal = 10.dp, vertical = 4.dp),
    )
}

@Composable
private fun ConfirmationView(w: WithdrawalEntity, onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(24.dp))
        CrownLogo(90.dp)
        Text("Request Submitted", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Gold)
        Spacer(Modifier.height(4.dp))
        StatusChip(w.status)
        Spacer(Modifier.height(16.dp))
        SoftCard(Modifier.fillMaxWidth()) {
            Line("Method", w.method)
            Line("Name", w.fullName)
            Line("Mobile", w.mobile)
            Line("Account", w.account)
            Line("Coins used", "%,d".format(w.coins))
            Line("Demo amount", "PKR ${"%,d".format(w.pkr)}")
        }
        Spacer(Modifier.height(12.dp))
        DemoNote("This is a demo request saved on your phone only. No payment will be made, and there is no real Paid status.")
        Spacer(Modifier.height(16.dp))
        GoldButton("Back to Withdraw", Modifier.fillMaxWidth(), onClick = onBack)
    }
}

@Composable
private fun Line(k: String, v: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(k, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(v, fontWeight = FontWeight.SemiBold)
    }
}
