package com.rewardking.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rewardking.app.ui.components.*
import com.rewardking.app.ui.vm.AuthViewModel

@Composable
fun AuthScreen(onDone: () -> Unit, vm: AuthViewModel = viewModel()) {
    var register by rememberSaveable { mutableStateOf(!vm.hasAccount) }
    var name by rememberSaveable { mutableStateOf("") }
    var mobile by rememberSaveable { mutableStateOf(if (vm.hasAccount) vm.savedMobile else "") }
    var password by rememberSaveable { mutableStateOf("") }
    val error by vm.error.collectAsState()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(12.dp))
        CrownLogo(96.dp)
        Text("Reward King", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
        Text(
            if (register) "Create your local demo profile" else "Welcome back, King!",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(20.dp))
        if (register) {
            OutlinedTextField(name, { name = it }, label = { Text("Full name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
        }
        OutlinedTextField(
            mobile, { mobile = it.filter { c -> c.isDigit() }.take(11) },
            label = { Text("Mobile number (03XXXXXXXXX)") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            password, { password = it }, label = { Text("Password") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth(),
        )
        error?.let { Spacer(Modifier.height(8.dp)); Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
        Spacer(Modifier.height(18.dp))
        GoldButton(if (register) "Create Profile" else "Login", Modifier.fillMaxWidth()) {
            if (register) vm.register(name, mobile, password, onDone) else vm.login(mobile, password, onDone)
        }
        if (vm.hasAccount) {
            TextButton(onClick = { register = !register }) {
                Text(if (register) "I already have a profile" else "Create a new profile (replaces the old one)")
            }
        }
        Spacer(Modifier.height(16.dp))
        DemoNote(
            "This is a local demo profile stored only on this phone (password is hashed and kept in " +
                "Android secure storage). There is no server. Uninstalling the app or clearing its data erases " +
                "your coins, tasks, spin history and withdrawal requests."
        )
    }
}
