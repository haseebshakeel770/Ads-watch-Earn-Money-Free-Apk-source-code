package com.rewardking.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.store: DataStore<Preferences> by preferencesDataStore(name = "reward_king_prefs")

data class UserState(
    val loggedIn: Boolean = false,
    val name: String = "",
    val mobile: String = "",
    val coins: Int = 0,
    val totalEarned: Int = 0,
    val adsWatched: Int = 0,
    val streak: Int = 0,
    val lastCheckin: String = "",
    val lastLoginBonus: String = "",
    val spinsDate: String = "",
    val spinsToday: Int = 0,
    val adDate: String = "",
    val adsToday: Int = 0,
    val watchedAdDate: String = "",
    val wheelVisitDate: String = "",
    val challengeDate: String = "",
    val music: Boolean = true,
    val sound: Boolean = true,
    val dark: Boolean = true,
    val notifications: Boolean = true,
)

class UserPrefs(private val context: Context) {
    private object K {
        val loggedIn = booleanPreferencesKey("logged_in")
        val name = stringPreferencesKey("name")
        val mobile = stringPreferencesKey("mobile")
        val coins = intPreferencesKey("coins")
        val totalEarned = intPreferencesKey("total_earned")
        val adsWatched = intPreferencesKey("ads_watched")
        val streak = intPreferencesKey("streak")
        val lastCheckin = stringPreferencesKey("last_checkin")
        val lastLoginBonus = stringPreferencesKey("last_login_bonus")
        val spinsDate = stringPreferencesKey("spins_date")
        val spinsToday = intPreferencesKey("spins_today")
        val adDate = stringPreferencesKey("ad_date")
        val adsToday = intPreferencesKey("ads_today")
        val watchedAdDate = stringPreferencesKey("watched_ad_date")
        val wheelVisitDate = stringPreferencesKey("wheel_visit_date")
        val challengeDate = stringPreferencesKey("challenge_date")
        val music = booleanPreferencesKey("music")
        val sound = booleanPreferencesKey("sound")
        val dark = booleanPreferencesKey("dark")
        val notifications = booleanPreferencesKey("notifications")
    }

    val state: Flow<UserState> = context.store.data.map { p ->
        UserState(
            loggedIn = p[K.loggedIn] ?: false,
            name = p[K.name] ?: "",
            mobile = p[K.mobile] ?: "",
            coins = p[K.coins] ?: 0,
            totalEarned = p[K.totalEarned] ?: 0,
            adsWatched = p[K.adsWatched] ?: 0,
            streak = p[K.streak] ?: 0,
            lastCheckin = p[K.lastCheckin] ?: "",
            lastLoginBonus = p[K.lastLoginBonus] ?: "",
            spinsDate = p[K.spinsDate] ?: "",
            spinsToday = p[K.spinsToday] ?: 0,
            adDate = p[K.adDate] ?: "",
            adsToday = p[K.adsToday] ?: 0,
            watchedAdDate = p[K.watchedAdDate] ?: "",
            wheelVisitDate = p[K.wheelVisitDate] ?: "",
            challengeDate = p[K.challengeDate] ?: "",
            music = p[K.music] ?: true,
            sound = p[K.sound] ?: true,
            dark = p[K.dark] ?: true,
            notifications = p[K.notifications] ?: true,
        )
    }

    suspend fun setProfile(name: String, mobile: String) {
        context.store.edit {
            it[K.name] = name; it[K.mobile] = mobile; it[K.loggedIn] = true
        }
    }

    suspend fun setLoggedIn(v: Boolean) { context.store.edit { it[K.loggedIn] = v } }

    /** Atomic add of coins. Positive amounts also raise the lifetime total. */
    suspend fun addCoins(delta: Int, countAsEarned: Boolean = true) {
        context.store.edit {
            it[K.coins] = ((it[K.coins] ?: 0) + delta).coerceAtLeast(0)
            if (delta > 0 && countAsEarned) it[K.totalEarned] = (it[K.totalEarned] ?: 0) + delta
        }
    }

    /** Spends coins only if the balance is enough. Returns true when spent. */
    suspend fun trySpend(amount: Int): Boolean {
        var ok = false
        context.store.edit {
            val cur = it[K.coins] ?: 0
            if (cur >= amount) { it[K.coins] = cur - amount; ok = true }
        }
        return ok
    }

    suspend fun incAdsWatched(today: String) {
        context.store.edit {
            it[K.adsWatched] = (it[K.adsWatched] ?: 0) + 1
            it[K.watchedAdDate] = today
            val same = it[K.adDate] == today
            it[K.adDate] = today
            it[K.adsToday] = if (same) (it[K.adsToday] ?: 0) + 1 else 1
        }
    }

    suspend fun setCheckin(today: String, streak: Int) {
        context.store.edit { it[K.lastCheckin] = today; it[K.streak] = streak }
    }

    suspend fun setLoginBonus(today: String) { context.store.edit { it[K.lastLoginBonus] = today } }

    suspend fun useSpin(today: String) {
        context.store.edit {
            val same = it[K.spinsDate] == today
            it[K.spinsDate] = today
            it[K.spinsToday] = if (same) (it[K.spinsToday] ?: 0) + 1 else 1
        }
    }

    suspend fun setWheelVisit(today: String) { context.store.edit { it[K.wheelVisitDate] = today } }
    suspend fun setChallengeSolved(today: String) { context.store.edit { it[K.challengeDate] = today } }

    suspend fun setMusic(v: Boolean) { context.store.edit { it[K.music] = v } }
    suspend fun setSound(v: Boolean) { context.store.edit { it[K.sound] = v } }
    suspend fun setDark(v: Boolean) { context.store.edit { it[K.dark] = v } }
    suspend fun setNotifications(v: Boolean) { context.store.edit { it[K.notifications] = v } }
}
