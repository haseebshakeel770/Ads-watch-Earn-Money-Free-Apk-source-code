package com.rewardking.app.ads

import android.app.Activity
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.SystemClock
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.*
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.rewardking.app.R
import com.rewardking.app.config.AppConfig

fun isOnline(context: Context): Boolean {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

/**
 * Wraps Google Mobile Ads SDK. Ad unit IDs come from res/values/ad_config.xml
 * (currently Google's official TEST IDs).
 */
class AdsManager(private val context: Context) {
    private var rewarded: RewardedAd? = null
    private var rewardedLoading = false
    private var interstitial: InterstitialAd? = null
    private var interstitialLoading = false
    private var lastRewardedAt = 0L
    private var lastInterstitialAt = 0L

    init {
        MobileAds.initialize(context) { }
        loadRewarded()
        loadInterstitial()
    }

    fun bannerId(): String = context.getString(R.string.admob_banner_id)

    fun loadRewarded() {
        if (rewarded != null || rewardedLoading) return
        rewardedLoading = true
        RewardedAd.load(
            context,
            context.getString(R.string.admob_rewarded_id),
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) { rewarded = ad; rewardedLoading = false }
                override fun onAdFailedToLoad(error: LoadAdError) { rewarded = null; rewardedLoading = false }
            }
        )
    }

    fun loadInterstitial() {
        if (interstitial != null || interstitialLoading) return
        interstitialLoading = true
        InterstitialAd.load(
            context,
            context.getString(R.string.admob_interstitial_id),
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) { interstitial = ad; interstitialLoading = false }
                override fun onAdFailedToLoad(error: LoadAdError) { interstitial = null; interstitialLoading = false }
            }
        )
    }

    /** Seconds the user must still wait before the next rewarded ad (0 = ready). */
    fun cooldownLeftSeconds(): Int {
        val left = AppConfig.REWARDED_COOLDOWN_MS - (SystemClock.elapsedRealtime() - lastRewardedAt)
        return if (lastRewardedAt == 0L || left <= 0) 0 else ((left + 999) / 1000).toInt()
    }

    /**
     * Shows a rewarded ad. [onReward] is called AT MOST ONCE and ONLY from the SDK's
     * OnUserEarnedRewardListener (i.e. the ad was completed). Closing early gives nothing.
     */
    fun showRewarded(activity: Activity, onReward: () -> Unit, onUnavailable: (String) -> Unit) {
        val ad = rewarded
        if (ad == null) {
            loadRewarded()
            onUnavailable("Ad is not ready yet. Please try again in a moment.")
            return
        }
        var rewardGiven = false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewarded = null
                loadRewarded()
            }
            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                rewarded = null
                loadRewarded()
                onUnavailable("Ad could not be shown. Please try again.")
            }
        }
        rewarded = null // each ad object can be shown only once
        lastRewardedAt = SystemClock.elapsedRealtime()
        ad.show(activity, OnUserEarnedRewardListener {
            if (!rewardGiven) {
                rewardGiven = true
                onReward()
            }
        })
    }

    /** Shows an interstitial only if the minimum interval has passed. */
    fun maybeShowInterstitial(activity: Activity) {
        val now = SystemClock.elapsedRealtime()
        if (lastInterstitialAt != 0L && now - lastInterstitialAt < AppConfig.INTERSTITIAL_MIN_INTERVAL_MS) return
        val ad = interstitial ?: run { loadInterstitial(); return }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { interstitial = null; loadInterstitial() }
            override fun onAdFailedToShowFullScreenContent(error: AdError) { interstitial = null; loadInterstitial() }
        }
        interstitial = null
        lastInterstitialAt = now
        ad.show(activity)
    }
}

@Composable
fun BannerAd(unitId: String, modifier: Modifier = Modifier) {
    val view = remember { mutableListOf<AdView>() }
    AndroidView(
        modifier = modifier.fillMaxWidth(),
        factory = { ctx ->
            AdView(ctx).apply {
                setAdSize(AdSize.BANNER)
                this.adUnitId = unitId
                loadAd(AdRequest.Builder().build())
                view.add(this)
            }
        }
    )
    DisposableEffect(Unit) {
        onDispose { view.forEach { it.destroy() }; view.clear() }
    }
}
