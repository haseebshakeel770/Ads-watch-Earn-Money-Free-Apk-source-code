package com.rewardking.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,      // AD, CHECKIN, TASK, WHEEL, BONUS, WITHDRAW
    val amount: Int,       // + earned / - spent
    val note: String,
    val time: Long,
)

@Entity(tableName = "withdrawals")
data class WithdrawalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val method: String,
    val fullName: String,
    val mobile: String,
    val account: String,
    val coins: Int,
    val pkr: Int,
    val status: String,    // PENDING, APPROVED, REJECTED (demo UI states)
    val time: Long,
)

@Entity(tableName = "task_claims", primaryKeys = ["taskId", "dateKey"])
data class TaskClaimEntity(val taskId: String, val dateKey: String)

@Entity(tableName = "spins")
data class SpinEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reward: Int,
    val time: Long,
)

@Dao
interface AppDao {
    @Insert suspend fun insertTransaction(t: TransactionEntity)
    @Query("SELECT * FROM transactions ORDER BY time DESC") fun transactions(): Flow<List<TransactionEntity>>

    @Insert suspend fun insertWithdrawal(w: WithdrawalEntity)
    @Query("SELECT * FROM withdrawals ORDER BY time DESC") fun withdrawals(): Flow<List<WithdrawalEntity>>
    @Query("UPDATE withdrawals SET status = :status WHERE id = :id") suspend fun setWithdrawalStatus(id: Long, status: String)

    /** Returns -1 if this task was already claimed for that date (duplicate prevention). */
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertClaim(c: TaskClaimEntity): Long
    @Query("SELECT taskId FROM task_claims WHERE dateKey = :dateKey") fun claimedToday(dateKey: String): Flow<List<String>>

    @Insert suspend fun insertSpin(s: SpinEntity)
    @Query("SELECT * FROM spins ORDER BY time DESC LIMIT 20") fun spins(): Flow<List<SpinEntity>>
}

@Database(
    entities = [TransactionEntity::class, WithdrawalEntity::class, TaskClaimEntity::class, SpinEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AppDao
}
