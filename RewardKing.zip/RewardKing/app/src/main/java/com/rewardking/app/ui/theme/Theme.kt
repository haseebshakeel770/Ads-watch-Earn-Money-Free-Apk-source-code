package com.rewardking.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val Gold = Color(0xFFFFC107)
val GoldDeep = Color(0xFFFF8F00)
val Purple = Color(0xFF6A3CD8)
val PurpleDeep = Color(0xFF2A1565)
val Night = Color(0xFF1A1033)
val Green = Color(0xFF2E7D32)
val Red = Color(0xFFC62828)

val GoldGradient = Brush.linearGradient(listOf(Gold, GoldDeep))
val PurpleGradient = Brush.linearGradient(listOf(Purple, PurpleDeep))

private val DarkColors = darkColorScheme(
    primary = Gold, onPrimary = Color(0xFF3A2A00),
    secondary = Color(0xFFB69CFF), tertiary = Color(0xFF7BE0A0),
    background = Night, onBackground = Color(0xFFF3ECFF),
    surface = Color(0xFF241848), onSurface = Color(0xFFF3ECFF),
    surfaceVariant = Color(0xFF30225E), onSurfaceVariant = Color(0xFFD0C4F0),
    error = Color(0xFFFF8A80),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFFB87400), onPrimary = Color.White,
    secondary = Purple, tertiary = Green,
    background = Color(0xFFFBF7FF), onBackground = Color(0xFF1C1530),
    surface = Color.White, onSurface = Color(0xFF1C1530),
    surfaceVariant = Color(0xFFEFE8FF), onSurfaceVariant = Color(0xFF4A3F66),
    error = Red,
)

@Composable
fun RewardKingTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
