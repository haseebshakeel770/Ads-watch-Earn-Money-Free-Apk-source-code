package com.rewardking.app.ui.vm

import android.app.Activity
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rewardking.app.Graph
import com.rewardking.app.ads.isOnline
import com.rewardking.app.audio.Sfx
import com.rewardking.app.config.*
import com.rewardking.app.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class Popup(val title: String, val message: String, val coins: Int)

class AuthViewModel : ViewModel() {
    private val repo = Graph.repo
    val hasAccount get() = repo.hasAccount()
    val savedMobile get() = repo.savedMobile()
    val error = MutableStateFlow<String?>(null)

    private val mobileRegex = Regex("^03\\d{9}$")

    fun register(name: String, mobile: String, password: String, onDone: () -> Unit) {
        when {
            name.trim().length < 3 -> error.value = "Enter your full name (min 3 letters)."
            !mobileRegex.matches(mobile) -> error.value = "Mobile must look like 03XXXXXXXXX."
            password.length < 6 -> error.value = "Password must be at least 6 characters."
            else -> viewModelScope.launch {
                repo.register(name.trim(), mobile, password)
                repo.dailyLoginBonus()
                error.value = null
                onDone()
            }
        }
    }

    fun login(mobile: String, password: String, onDone: () -> Unit) {
        viewModelScope.launch {
            if (repo.login(mobile, password)) {
                error.value = null
                onDone()
            } else error.value = "Wrong mobile number or password."
        }
    }
}

class MainViewModel : ViewModel() {
    private val repo = Graph.repo
    private val ads = Graph.ads
    private val sound = Graph.sound

    val user: StateFlow<UserState> = repo.user.stateIn(viewModelScope, SharingStarted.Eagerly, UserState())
    val transactions: StateFlow<List<TransactionEntity>> =
        repo.transactions.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val withdrawals: StateFlow<List<WithdrawalEntity>> =
        repo.withdrawals.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val spins: StateFlow<List<SpinEntity>> =
        repo.spins.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val claimed: StateFlow<List<String>> =
        repo.claimedToday().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val popup = MutableStateFlow<Popup?>(null)
    val toast = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val lastWithdrawal = MutableStateFlow<WithdrawalEntity?>(null)
    val adLoading = MutableStateFlow(false)

    fun click() = sound.play(Sfx.CLICK)
    fun dismissPopup() { popup.value = null }
    fun isTaskComplete(t: TaskDef) = repo.isTaskComplete(t, user.value)
    fun spinsLeft() = repo.spinsLeft(user.value)

    fun onAppOpened() = viewModelScope.launch {
        val bonus = repo.dailyLoginBonus()
        if (bonus > 0) {
            sound.play(Sfx.COIN)
            popup.value = Popup("Daily Login Bonus", "Welcome back! Here is your daily bonus.", bonus)
        }
    }

    fun checkIn() = viewModelScope.launch {
        val c = repo.checkIn()
        if (c > 0) {
            sound.play(Sfx.CLAIM)
            popup.value = Popup("Check-in Complete", "See you tomorrow to keep your streak!", c)
        } else toast.tryEmit("You already checked in today.")
    }

    fun claimTask(t: TaskDef) = viewModelScope.launch {
        val c = repo.claimTask(t)
        if (c > 0) {
            sound.play(Sfx.CLAIM)
            popup.value = Popup("Task Reward", t.title, c)
        } else toast.tryEmit("Complete the task first (or it is already claimed).")
    }

    fun submitChallenge(answer: String, onResult: (Boolean) -> Unit) = viewModelScope.launch {
        val n = answer.trim().toIntOrNull()
        val ok = n != null && repo.submitChallenge(n)
        sound.play(if (ok) Sfx.CLAIM else Sfx.CLICK)
        onResult(ok)
    }

    fun visitWheel() = viewModelScope.launch { repo.markWheelVisit() }

    fun watchAd(activity: Activity) {
        val s = user.value
        val today = dateKey()
        if (!isOnline(activity)) { toast.tryEmit("No internet connection. Ads need internet."); return }
        if (s.adDate == today && s.adsToday >= AppConfig.MAX_REWARDED_PER_DAY) {
            toast.tryEmit("Daily ad limit reached (${AppConfig.MAX_REWARDED_PER_DAY}). Come back tomorrow."); return
        }
        val wait = ads.cooldownLeftSeconds()
        if (wait > 0) { toast.tryEmit("Please wait $wait seconds before the next ad."); return }
        sound.play(Sfx.CLICK)
        ads.showRewarded(
            activity,
            onReward = {
                viewModelScope.launch {
                    repo.rewardAd()
                    sound.play(Sfx.COIN)
                    popup.value = Popup("Reward Earned", "Thanks for watching the ad!", AppConfig.COINS_PER_REWARDED_AD)
                }
            },
            onUnavailable = { msg -> toast.tryEmit(msg) },
        )
    }

    fun maybeInterstitial(activity: Activity) = ads.maybeShowInterstitial(activity)

    /** Returns reward index (for the wheel animation) or -1. Coins are paid inside the repository. */
    suspend fun spin(): Int {
        val idx = repo.spinNow()
        if (idx >= 0) sound.play(Sfx.WHEEL)
        return idx
    }

    fun wheelFinished(idx: Int) {
        sound.play(Sfx.COIN)
        popup.value = Popup("Lucky Wheel", "You won!", AppConfig.WHEEL_REWARDS[idx])
    }

    fun submitWithdrawal(method: String, name: String, mobile: String, account: String, pkg: WithdrawPackage) =
        viewModelScope.launch {
            val w = repo.submitWithdrawal(method, name.trim(), mobile, account, pkg)
            if (w == null) toast.tryEmit("Not enough coins for this package.")
            else { sound.play(Sfx.SUBMIT); lastWithdrawal.value = w }
        }

    fun demoStatus(w: WithdrawalEntity, status: String) = viewModelScope.launch { repo.demoSetStatus(w, status) }
    fun clearLastWithdrawal() { lastWithdrawal.value = null }

    fun logout(onDone: () -> Unit) = viewModelScope.launch { repo.logout(); onDone() }

    fun setMusic(v: Boolean) = viewModelScope.launch { repo.setMusic(v) }
    fun setSound(v: Boolean) = viewModelScope.launch { repo.setSound(v) }
    fun setDark(v: Boolean) = viewModelScope.launch { repo.setDark(v) }
    fun setNotifications(v: Boolean) = viewModelScope.launch { repo.setNotifications(v) }
}
