package com.rewardking.app.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rewardking.app.config.AppConfig
import com.rewardking.app.data.TransactionEntity
import com.rewardking.app.ui.theme.*
import com.rewardking.app.ui.vm.Popup
import java.text.SimpleDateFormat
import java.util.*

/** Crown + gold coin logo drawn with Canvas. */
@Composable
fun CrownLogo(size: Dp = 120.dp, animated: Boolean = true) {
    val scale = remember { Animatable(if (animated) 0.2f else 1f) }
    LaunchedEffect(Unit) {
        if (animated) scale.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = 120f))
    }
    val inf = rememberInfiniteTransition(label = "logo")
    val shine by inf.animateFloat(
        0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Reverse), label = "shine"
    )
    Canvas(Modifier.size(size).scale(scale.value)) {
        val w = this.size.width
        val h = this.size.height
        val crown = Path().apply {
            moveTo(w * 0.12f, h * 0.60f)
            lineTo(w * 0.18f, h * 0.22f)
            lineTo(w * 0.34f, h * 0.40f)
            lineTo(w * 0.50f, h * 0.12f)
            lineTo(w * 0.66f, h * 0.40f)
            lineTo(w * 0.82f, h * 0.22f)
            lineTo(w * 0.88f, h * 0.60f)
            close()
        }
        drawPath(crown, Brush.linearGradient(listOf(Gold, GoldDeep), Offset(0f, 0f), Offset(w, h)))
        drawRect(GoldDeep, Offset(w * 0.12f, h * 0.62f), Size(w * 0.76f, h * 0.10f))
        listOf(0.18f to 0.20f, 0.50f to 0.10f, 0.82f to 0.20f).forEach { (x, y) ->
            drawCircle(Color.White, w * 0.045f, Offset(w * x, h * y))
        }
        val c = Offset(w * 0.5f, h * 0.84f)
        val r = w * 0.15f
        drawCircle(Brush.radialGradient(listOf(Color(0xFFFFE082), Gold), c, r), r, c)
        drawCircle(GoldDeep, r, c, style = Stroke(w * 0.015f))
        drawCircle(GoldDeep.copy(alpha = 0.5f + 0.4f * shine), r * 0.5f, c)
    }
}

@Composable
fun GradientCard(
    modifier: Modifier = Modifier,
    brush: Brush = PurpleGradient,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val m = modifier.clip(RoundedCornerShape(22.dp)).background(brush)
    Column(
        (if (onClick != null) m.clickable { onClick() } else m).padding(18.dp),
        content = content,
    )
}

@Composable
fun SoftCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp),
    ) { Column(Modifier.padding(16.dp), content = content) }
}

@Composable
fun GoldButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (enabled) GoldGradient else Brush.linearGradient(listOf(Color.Gray, Color.DarkGray)))
            .clickable(enabled = enabled) { onClick() }
            .padding(horizontal = 20.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Color(0xFF3A2A00), fontWeight = FontWeight.Bold, fontSize = 16.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
}

@Composable
fun CoinText(coins: Int, color: Color = Gold, size: Int = 28) {
    val shown by animateIntAsState(coins, tween(700), label = "coins")
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.MonetizationOn, null, tint = color, modifier = Modifier.size((size + 4).dp))
        Spacer(Modifier.width(6.dp))
        Text("%,d".format(shown), color = color, fontWeight = FontWeight.ExtraBold, fontSize = size.sp)
    }
}

@Composable
fun TestModeChip() {
    if (AppConfig.TEST_MODE) {
        Text(
            "TEST ADS MODE",
            Modifier.clip(RoundedCornerShape(50)).background(Color(0x33FFFFFF)).padding(horizontal = 10.dp, vertical = 3.dp),
            fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Gold,
        )
    }
}

@Composable
fun DemoNote(text: String, modifier: Modifier = Modifier) {
    Text(
        text, modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            .background(Color(0x22FFC107)).padding(12.dp),
        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
fun LoadingDots(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = Gold)
    }
}

@Composable
fun EmptyState(title: String, subtitle: String, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        CrownLogo(64.dp, animated = false)
        Spacer(Modifier.height(8.dp))
        Text(title, fontWeight = FontWeight.Bold)
        Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

fun formatTime(t: Long): String = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(t))

@Composable
fun TransactionRow(t: TransactionEntity) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(40.dp).clip(CircleShape)
                .background(if (t.amount >= 0) Color(0x332E7D32) else Color(0x33C62828)),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                when (t.type) { "AD" -> "▶"; "WHEEL" -> "★"; "CHECKIN" -> "✓"; "TASK" -> "☑"; "WITHDRAW" -> "↑"; else -> "+" },
                fontWeight = FontWeight.Bold,
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(t.note, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(formatTime(t.time), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(
            (if (t.amount >= 0) "+" else "") + t.amount,
            fontWeight = FontWeight.Bold,
            color = if (t.amount >= 0) Green else Red,
        )
    }
}

/** Reward popup with a bouncing coin. */
@Composable
fun RewardPopup(popup: Popup, onDismiss: () -> Unit) {
    val bounce = remember { Animatable(0f) }
    LaunchedEffect(popup) { bounce.animateTo(1f, spring(dampingRatio = 0.35f, stiffness = 150f)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { GoldButton("Awesome!", onClick = onDismiss) },
        title = { Text(popup.title, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) },
        text = {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.MonetizationOn, null, tint = Gold, modifier = Modifier.size(84.dp).scale(bounce.value))
                Text("+${popup.coins} Coins", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Gold)
                Spacer(Modifier.height(6.dp))
                Text(popup.message, textAlign = TextAlign.Center)
            }
        },
        shape = RoundedCornerShape(28.dp),
    )
}
