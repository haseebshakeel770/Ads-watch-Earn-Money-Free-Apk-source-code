package com.rewardking.app.data

import com.rewardking.app.config.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.text.SimpleDateFormat
import java.util.*

fun dateKey(offsetDays: Int = 0): String {
    val c = Calendar.getInstance()
    c.add(Calendar.DAY_OF_YEAR, offsetDays)
    return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.time)
}

fun startOfToday(): Long {
    val c = Calendar.getInstance()
    c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

/** Deterministic daily maths question: (a, b, answer). Same all day, changes tomorrow. */
fun dailyChallenge(key: String = dateKey()): Triple<Int, Int, Int> {
    val r = Random(key.hashCode().toLong())
    val a = 10 + r.nextInt(40)
    val b = 10 + r.nextInt(40)
    return Triple(a, b, a + b)
}

class Repository(
    private val prefs: UserPrefs,
    private val dao: AppDao,
    private val secure: SecureStore,
) {
    val user: Flow<UserState> = prefs.state
    val transactions: Flow<List<TransactionEntity>> = dao.transactions()
    val withdrawals: Flow<List<WithdrawalEntity>> = dao.withdrawals()
    val spins: Flow<List<SpinEntity>> = dao.spins()
    fun claimedToday(): Flow<List<String>> = dao.claimedToday(dateKey())

    private suspend fun earn(type: String, amount: Int, note: String) {
        prefs.addCoins(amount)
        dao.insertTransaction(TransactionEntity(type = type, amount = amount, note = note, time = System.currentTimeMillis()))
    }

    // ---------- Auth (local demo profile) ----------
    fun hasAccount() = secure.hasAccount()
    fun savedMobile() = secure.savedMobile()

    suspend fun register(name: String, mobile: String, password: String) {
        secure.register(mobile, password)
        prefs.setProfile(name, mobile)
    }

    suspend fun login(mobile: String, password: String): Boolean {
        if (!secure.verify(mobile, password)) return false
        prefs.setLoggedIn(true)
        return true
    }

    suspend fun logout() = prefs.setLoggedIn(false)

    // ---------- Rewards ----------
    /** Called ONLY from the SDK's reward callback. */
    suspend fun rewardAd() {
        prefs.incAdsWatched(dateKey())
        earn("AD", AppConfig.COINS_PER_REWARDED_AD, "Rewarded ad")
    }

    /** Returns bonus given (0 if already received today). */
    suspend fun dailyLoginBonus(): Int {
        val s = user.first()
        val today = dateKey()
        if (s.lastLoginBonus == today) return 0
        prefs.setLoginBonus(today)
        earn("BONUS", AppConfig.LOGIN_BONUS, "Daily login bonus")
        return AppConfig.LOGIN_BONUS
    }

    /** Returns coins given (0 if already checked in today). */
    suspend fun checkIn(): Int {
        val s = user.first()
        val today = dateKey()
        if (s.lastCheckin == today) return 0
        val streak = if (s.lastCheckin == dateKey(-1)) s.streak + 1 else 1
        if (dao.insertClaim(TaskClaimEntity("checkin", today)) == -1L) return 0
        prefs.setCheckin(today, streak)
        val reward = AppConfig.CHECKIN_BASE + (minOf(streak, AppConfig.CHECKIN_STREAK_MAX) - 1) * AppConfig.CHECKIN_STREAK_STEP
        earn("CHECKIN", reward, "Daily check-in (day $streak)")
        return reward
    }

    suspend fun markWheelVisit() = prefs.setWheelVisit(dateKey())

    suspend fun submitChallenge(answer: Int): Boolean {
        if (answer != dailyChallenge().third) return false
        prefs.setChallengeSolved(dateKey())
        return true
    }

    fun isTaskComplete(task: TaskDef, s: UserState): Boolean {
        val today = dateKey()
        return when (task.id) {
            "checkin" -> s.lastCheckin == today
            "watch_ad" -> s.watchedAdDate == today
            "visit_wheel" -> s.wheelVisitDate == today
            "challenge" -> s.challengeDate == today
            "open_app" -> true
            else -> false
        }
    }

    /** Validates completion and claims once per day. Returns coins given or 0. */
    suspend fun claimTask(task: TaskDef): Int {
        if (task.id == "checkin") return checkIn()
        val s = user.first()
        if (!isTaskComplete(task, s)) return 0
        if (dao.insertClaim(TaskClaimEntity(task.id, dateKey())) == -1L) return 0
        earn("TASK", task.reward, task.title)
        return task.reward
    }

    // ---------- Lucky wheel ----------
    fun spinsLeft(s: UserState): Int {
        val used = if (s.spinsDate == dateKey()) s.spinsToday else 0
        return (AppConfig.DAILY_SPIN_LIMIT - used).coerceAtLeast(0)
    }

    /**
     * Picks the reward, consumes one spin and pays the coins in one step so the
     * reward can never be given twice. Returns the reward index, or -1 if no spins left.
     */
    suspend fun spinNow(): Int {
        val s = user.first()
        if (spinsLeft(s) <= 0) return -1
        val weights = AppConfig.WHEEL_WEIGHTS
        var roll = Random().nextInt(weights.sum())
        var idx = 0
        for (i in weights.indices) {
            if (roll < weights[i]) { idx = i; break }
            roll -= weights[i]
        }
        val reward = AppConfig.WHEEL_REWARDS[idx]
        prefs.useSpin(dateKey())
        dao.insertSpin(SpinEntity(reward = reward, time = System.currentTimeMillis()))
        earn("WHEEL", reward, "Lucky wheel")
        return idx
    }

    // ---------- Withdrawal (DEMO ONLY: nothing is ever paid) ----------
    suspend fun submitWithdrawal(method: String, name: String, mobile: String, account: String, pkg: WithdrawPackage): WithdrawalEntity? {
        if (!prefs.trySpend(pkg.coins)) return null
        val w = WithdrawalEntity(
            method = method, fullName = name, mobile = mobile, account = account,
            coins = pkg.coins, pkr = pkg.pkr, status = "PENDING", time = System.currentTimeMillis(),
        )
        dao.insertWithdrawal(w)
        dao.insertTransaction(TransactionEntity(type = "WITHDRAW", amount = -pkg.coins, note = "Demo withdrawal ($method)", time = w.time))
        return w
    }

    /** Demo helper so every UI state can be seen without a backend. */
    suspend fun demoSetStatus(w: WithdrawalEntity, status: String) {
        if (w.status != "PENDING") return
        dao.setWithdrawalStatus(w.id, status)
        if (status == "REJECTED") {
            prefs.addCoins(w.coins, countAsEarned = false)
            dao.insertTransaction(TransactionEntity(type = "BONUS", amount = w.coins, note = "Demo refund (rejected)", time = System.currentTimeMillis()))
        }
    }

    // ---------- Settings ----------
    suspend fun setMusic(v: Boolean) = prefs.setMusic(v)
    suspend fun setSound(v: Boolean) = prefs.setSound(v)
    suspend fun setDark(v: Boolean) = prefs.setDark(v)
    suspend fun setNotifications(v: Boolean) = prefs.setNotifications(v)
}
