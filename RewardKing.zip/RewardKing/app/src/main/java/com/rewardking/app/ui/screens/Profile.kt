package com.rewardking.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rewardking.app.config.AppConfig
import com.rewardking.app.ui.components.*
import com.rewardking.app.ui.theme.*
import com.rewardking.app.ui.vm.MainViewModel

@Composable
fun ProfileScreen(vm: MainViewModel, go: (String) -> Unit, onLogout: () -> Unit) {
    val user by vm.user.collectAsState()
    val withdrawals by vm.withdrawals.collectAsState()
    val demoPkr = user.totalEarned / 10 // illustrative: 100 coins = PKR 10

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        CrownLogo(80.dp, animated = false)
        Text(user.name.ifBlank { "King" }, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        Text(user.mobile, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(14.dp))

        GradientCard(Modifier.fillMaxWidth()) {
            CoinText(user.coins, size = 30)
            Text("Current coins", color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth()) {
                Mini("Total demo earnings", "PKR $demoPkr", Modifier.weight(1f))
                Mini("Ads watched", "${user.adsWatched}", Modifier.weight(1f))
                Mini("Withdrawals", "${withdrawals.size}", Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(14.dp))

        SoftCard(Modifier.fillMaxWidth()) {
            MenuRow("Transaction History") { vm.click(); go("history") }
            MenuRow("Notifications") { vm.click(); go("notifications") }
            MenuRow("Settings") { vm.click(); go("settings") }
            MenuRow("Privacy Policy") { vm.click(); go("privacy") }
            MenuRow("Terms & Conditions") { vm.click(); go("terms") }
            MenuRow("Logout") { vm.logout(onLogout) }
        }
        Spacer(Modifier.height(12.dp))
        DemoNote("Local demo data: coins, tasks, spin history and withdrawal requests live only on this phone. Uninstalling the app or clearing its data erases them.")
        Spacer(Modifier.height(8.dp))
        Text("Reward King v${AppConfig.APP_VERSION}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun Mini(label: String, value: String, modifier: Modifier) {
    Column(modifier) {
        Text(value, color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(label, color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.7f), fontSize = 10.sp)
    }
}

@Composable
private fun MenuRow(text: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
        Text("›", fontSize = 20.sp, color = Gold)
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
}
