package com.rewardking.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rewardking.app.config.AppConfig
import com.rewardking.app.ui.components.*
import com.rewardking.app.ui.vm.MainViewModel

@Composable
fun HistoryScreen(vm: MainViewModel) {
    val txs by vm.transactions.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Transaction History", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(8.dp))
        if (txs.isEmpty()) EmptyState("Nothing here yet", "Earn or withdraw coins and your history will show up here.")
        else LazyColumn { items(txs, key = { it.id }) { TransactionRow(it) } }
    }
}

@Composable
fun NotificationsScreen(vm: MainViewModel) {
    val user by vm.user.collectAsState()
    val txs by vm.transactions.collectAsState()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Notifications", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(8.dp))
        if (!user.notifications) {
            EmptyState("Notifications are off", "Turn them on from Settings to see updates here.")
            return@Column
        }
        SoftCard(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
            Text("Welcome to Reward King 👑", fontWeight = FontWeight.Bold)
            Text("Check in daily, watch ads, spin the wheel and finish tasks to collect demo coins.", fontSize = 13.sp)
        }
        txs.take(10).forEach {
            SoftCard(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                Text(if (it.amount >= 0) "You earned ${it.amount} coins" else "You used ${-it.amount} coins", fontWeight = FontWeight.Bold)
                Text("${it.note} • ${formatTime(it.time)}", fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val u by vm.user.collectAsState()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Settings", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(8.dp))
        SoftCard(Modifier.fillMaxWidth()) {
            SwitchRow("Background music", u.music) { vm.setMusic(it) }
            SwitchRow("Sound effects", u.sound) { vm.setSound(it) }
            SwitchRow("Dark theme", u.dark) { vm.setDark(it) }
            SwitchRow("Notifications", u.notifications) { vm.setNotifications(it) }
        }
        Spacer(Modifier.height(12.dp))
        DemoNote("Ads: ${if (AppConfig.TEST_MODE) "Google TEST ads are active." else "Live ads are active."} Reward King v${AppConfig.APP_VERSION}.")
        Spacer(Modifier.height(8.dp))
        DemoNote("Data is stored only on this phone. Uninstalling the app or clearing its data erases it.")
    }
}

@Composable
private fun SwitchRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = value, onCheckedChange = onChange)
    }
}

@Composable
fun LegalScreen(title: String, body: String) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(10.dp))
        Text(body, fontSize = 14.sp, lineHeight = 21.sp)
    }
}

val PRIVACY_TEXT = """
Privacy Policy (Demo version)

1. What this app stores
Reward King stores your name, mobile number, coins, task claims, spin history, withdrawal requests and settings only on your phone. Your password is never saved as plain text; only a salted hash is kept in Android secure storage. There is no server and no cloud account.

2. Advertising
This app shows ads using the Google Mobile Ads SDK (AdMob). Google may collect device identifiers such as the advertising ID, IP address and ad interaction data to serve and measure ads. See Google's policy at policies.google.com/privacy. During development this app uses Google's official test ads.

3. Data deletion
Uninstalling the app or clearing its storage permanently deletes all local data. We cannot recover it.

4. Children
This app is not intended for children under 13.

5. Contact
Replace this section with your real support email before publishing.

Note: this is sample text for testing. Before publishing on Google Play, have your final privacy policy hosted at a public URL.
""".trimIndent()

val TERMS_TEXT = """
Terms & Conditions (Demo version)

1. Demo application
Reward King is a demo. Coins have no cash value. Withdrawal screens, packages and PKR amounts are examples only. No payment is made, promised or guaranteed.

2. Fair use
You must not click ads on purpose, use bots, emulators or any method to generate fake ad views or clicks. Rewards are given only after an ad is fully completed. Daily limits apply to ads and spins.

3. Local data
Your progress is stored only on your device and may be lost if you uninstall the app or clear its data.

4. No warranty
The app is provided as is, without warranties of any kind.

5. Changes
These terms may change in future versions. Replace this text with your final terms before publishing.
""".trimIndent()
