package com.rewardking.app

import android.app.Application

class RewardKingApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Graph.init(this)
    }
}
