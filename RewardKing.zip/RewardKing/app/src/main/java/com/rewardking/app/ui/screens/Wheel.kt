package com.rewardking.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rewardking.app.config.AppConfig
import com.rewardking.app.ui.components.*
import com.rewardking.app.ui.theme.*
import com.rewardking.app.ui.vm.MainViewModel
import kotlinx.coroutines.launch
import kotlin.random.Random

private val SegmentColors = listOf(
    Color(0xFF7E57C2), Color(0xFFEF6C00), Color(0xFF00897B), Color(0xFFC2185B),
    Color(0xFF1E88E5), Color(0xFF6D4C41), Color(0xFFD4A017),
)

@Composable
fun WheelScreen(vm: MainViewModel) {
    val user by vm.user.collectAsState()
    val spins by vm.spins.collectAsState()
    val rotation = remember { Animatable(0f) }
    var spinning by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val rewards = AppConfig.WHEEL_REWARDS
    val seg = 360f / rewards.size
    val left = vm.spinsLeft()
    val paint = remember {
        android.graphics.Paint().apply {
            color = android.graphics.Color.WHITE
            textAlign = android.graphics.Paint.Align.CENTER
            isFakeBoldText = true
            isAntiAlias = true
        }
    }

    LaunchedEffect(Unit) { vm.visitWheel() }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Lucky Wheel", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        Text("Spins left today: $left / ${AppConfig.DAILY_SPIN_LIMIT}", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))

        Canvas(Modifier.size(300.dp)) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val r = size.minDimension / 2f - 14.dp.toPx()
            paint.textSize = size.width * 0.075f
            rotate(rotation.value, Offset(cx, cy)) {
                rewards.forEachIndexed { i, v ->
                    drawArc(
                        color = SegmentColors[i % SegmentColors.size],
                        startAngle = -90f + i * seg, sweepAngle = seg, useCenter = true,
                        topLeft = Offset(cx - r, cy - r), size = Size(2 * r, 2 * r),
                    )
                    rotate(i * seg + seg / 2f, Offset(cx, cy)) {
                        drawContext.canvas.nativeCanvas.drawText("$v", cx, cy - r * 0.68f, paint)
                    }
                }
                drawCircle(Color(0xFFFFD54F), r * 0.14f, Offset(cx, cy))
            }
            drawCircle(Gold, r + 7.dp.toPx(), Offset(cx, cy), style = Stroke(12.dp.toPx()))
            val pointer = Path().apply {
                moveTo(cx - 14.dp.toPx(), 0f)
                lineTo(cx + 14.dp.toPx(), 0f)
                lineTo(cx, 30.dp.toPx())
                close()
            }
            drawPath(pointer, Color(0xFFE53935))
        }

        Spacer(Modifier.height(20.dp))
        GoldButton(
            if (spinning) "Spinning..." else if (left > 0) "SPIN" else "No spins left",
            Modifier.fillMaxWidth(0.7f), enabled = !spinning && left > 0,
        ) {
            if (spinning) return@GoldButton
            spinning = true
            scope.launch {
                val idx = vm.spin() // reward is decided and paid exactly once here
                if (idx < 0) { spinning = false; return@launch }
                val center = idx * seg + seg / 2f
                val jitter = (Random.nextFloat() - 0.5f) * seg * 0.6f
                val current = rotation.value
                val extra = ((-(center + jitter) - current) % 360f + 360f) % 360f
                rotation.animateTo(current + 360f * 5 + extra, tween(4500, easing = FastOutSlowInEasing))
                spinning = false
                vm.wheelFinished(idx)
            }
        }
        Spacer(Modifier.height(8.dp))
        DemoNote("Demo rewards: 5, 10, 15, 20, 25, 50 or 100 coins. Large prizes are rare. Limit: ${AppConfig.DAILY_SPIN_LIMIT} spins per day.")
        Spacer(Modifier.height(16.dp))
        SoftCard(Modifier.fillMaxWidth()) {
            SectionTitle("Recent spins")
            if (spins.isEmpty()) EmptyState("No spins yet", "Your wheel history will appear here.")
            else spins.take(8).forEach {
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Text(formatTime(it.time), Modifier.weight(1f), fontSize = 13.sp)
                    Text("+${it.reward}", color = Green, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
