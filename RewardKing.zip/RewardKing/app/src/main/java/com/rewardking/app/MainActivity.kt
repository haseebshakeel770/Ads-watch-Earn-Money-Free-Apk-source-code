package com.rewardking.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import com.rewardking.app.data.UserState
import com.rewardking.app.ui.nav.AppNav
import com.rewardking.app.ui.theme.RewardKingTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val user by Graph.repo.user.collectAsState(initial = UserState())
            LaunchedEffect(user.sound, user.music) {
                Graph.sound.applySettings(user.sound, user.music)
            }
            RewardKingTheme(dark = user.dark) {
                AppNav()
            }
        }
    }

    override fun onStart() {
        super.onStart()
        Graph.sound.onForeground()
    }

    override fun onStop() {
        super.onStop()
        Graph.sound.onBackground()
    }
}
