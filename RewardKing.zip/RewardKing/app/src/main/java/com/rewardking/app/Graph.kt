package com.rewardking.app

import android.content.Context
import androidx.room.Room
import com.rewardking.app.ads.AdsManager
import com.rewardking.app.audio.SoundManager
import com.rewardking.app.data.*

/** Tiny service locator (keeps the project dependency-injection-library free). */
object Graph {
    lateinit var repo: Repository
    lateinit var sound: SoundManager
    lateinit var ads: AdsManager

    fun init(context: Context) {
        val app = context.applicationContext
        val db = Room.databaseBuilder(app, AppDatabase::class.java, "reward_king.db").build()
        repo = Repository(UserPrefs(app), db.dao(), SecureStore(app))
        sound = SoundManager(app)
        ads = AdsManager(app)
    }
}
