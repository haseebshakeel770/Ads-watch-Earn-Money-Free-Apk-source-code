package com.rewardking.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rewardking.app.Graph
import com.rewardking.app.ui.components.CrownLogo
import com.rewardking.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first

@Composable
fun SplashScreen(onDone: (loggedIn: Boolean) -> Unit) {
    val fade = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        fade.animateTo(1f, tween(900))
        delay(1500)
        val s = Graph.repo.user.first()
        onDone(s.loggedIn && Graph.repo.hasAccount())
    }
    Column(
        Modifier.fillMaxSize().background(PurpleGradient),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        CrownLogo(150.dp)
        Spacer(Modifier.height(16.dp))
        Text("REWARD KING", Modifier.alpha(fade.value), color = Gold, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
        Text("Play. Earn. Rule.", Modifier.alpha(fade.value), color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
        Spacer(Modifier.height(36.dp))
        CircularProgressIndicator(color = Gold, strokeWidth = 3.dp, modifier = Modifier.size(28.dp))
    }
}
