package com.rewardking.app.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import com.rewardking.app.R

enum class Sfx { CLICK, COIN, WHEEL, CLAIM, SUBMIT }

class SoundManager(private val context: Context) {
    private val pool: SoundPool = SoundPool.Builder()
        .setMaxStreams(4)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        ).build()

    private val ids: Map<Sfx, Int> = mapOf(
        Sfx.CLICK to pool.load(context, R.raw.snd_click, 1),
        Sfx.COIN to pool.load(context, R.raw.snd_coin, 1),
        Sfx.WHEEL to pool.load(context, R.raw.snd_wheel, 1),
        Sfx.CLAIM to pool.load(context, R.raw.snd_claim, 1),
        Sfx.SUBMIT to pool.load(context, R.raw.snd_submit, 1),
    )

    var soundOn = true
    var musicOn = true
    private var player: MediaPlayer? = null
    private var inForeground = false

    fun play(s: Sfx) {
        if (!soundOn) return
        ids[s]?.let { pool.play(it, 1f, 1f, 1, 0, 1f) }
    }

    fun onForeground() { inForeground = true; updateMusic() }
    fun onBackground() { inForeground = false; updateMusic() }

    fun applySettings(sound: Boolean, music: Boolean) {
        soundOn = sound
        musicOn = music
        updateMusic()
    }

    private fun updateMusic() {
        if (musicOn && inForeground) {
            if (player == null) {
                player = MediaPlayer.create(context, R.raw.snd_music)?.apply {
                    isLooping = true
                    setVolume(0.35f, 0.35f)
                }
            }
            player?.let { if (!it.isPlaying) it.start() }
        } else {
            player?.let { if (it.isPlaying) it.pause() }
        }
    }
}
