package com.rewardking.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rewardking.app.ads.isOnline
import com.rewardking.app.config.*
import com.rewardking.app.data.dateKey
import com.rewardking.app.data.dailyChallenge
import com.rewardking.app.ui.components.*
import com.rewardking.app.ui.theme.*
import com.rewardking.app.ui.vm.MainViewModel

@Composable
fun EarnScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val activity = remember(ctx) { ctx.findActivity() }
    val user by vm.user.collectAsState()
    val claimed by vm.claimed.collectAsState()
    var showChallenge by remember { mutableStateOf(false) }
    val online = isOnline(ctx)
    val adsToday = if (user.adDate == dateKey()) user.adsToday else 0

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Earn Coins", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(12.dp))

        GradientCard(Modifier.fillMaxWidth(), GoldGradient) {
            Text("Watch & Earn", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = Color(0xFF3A2A00))
            Text(
                "Watch a full rewarded ad to get ${AppConfig.COINS_PER_REWARDED_AD} coins. " +
                    "Closing the ad early gives no reward.",
                color = Color(0xFF3A2A00), fontSize = 13.sp,
            )
            Spacer(Modifier.height(6.dp))
            Text("Today: $adsToday / ${AppConfig.MAX_REWARDED_PER_DAY} ads", color = Color(0xFF3A2A00), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                GoldButtonDark("Watch Ad  +${AppConfig.COINS_PER_REWARDED_AD}") { vm.watchAd(activity) }
            }
        }
        if (!online) {
            Spacer(Modifier.height(8.dp))
            Text(
                "No internet connection. Ads and rewards need internet.",
                color = MaterialTheme.colorScheme.error, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
            )
        }
        Spacer(Modifier.height(16.dp))
        SectionTitle("Daily Tasks")
        Spacer(Modifier.height(8.dp))
        DAILY_TASKS.forEach { t ->
            val isClaimed = t.id in claimed
            val complete = vm.isTaskComplete(t)
            SoftCard(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(t.title, fontWeight = FontWeight.Bold)
                        Text(t.desc, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Reward: ${t.reward} coins", fontSize = 12.sp, color = Gold, fontWeight = FontWeight.SemiBold)
                    }
                    when {
                        isClaimed -> Text("Claimed ✓", color = Green, fontWeight = FontWeight.Bold)
                        t.id == "challenge" && !complete -> GoldButton("Solve") { showChallenge = true }
                        t.id == "watch_ad" && !complete -> GoldButton("Watch") { vm.watchAd(activity) }
                        t.id == "visit_wheel" && !complete -> Text("Open Lucky Wheel", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        else -> GoldButton(if (t.id == "checkin") "Check in" else "Claim") { vm.claimTask(t) }
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }

    if (showChallenge) {
        val (a, b, _) = remember { dailyChallenge() }
        var answer by remember { mutableStateOf("") }
        var wrong by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { showChallenge = false },
            title = { Text("Daily Challenge") },
            text = {
                Column {
                    Text("What is $a + $b ?", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        answer, { answer = it.filter { c -> c.isDigit() }.take(4); wrong = false },
                        singleLine = true, label = { Text("Your answer") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    )
                    if (wrong) Text("Not correct, try again.", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.submitChallenge(answer) { ok -> if (ok) showChallenge = false else wrong = true }
                }) { Text("Submit") }
            },
            dismissButton = { TextButton(onClick = { showChallenge = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun GoldButtonDark(text: String, onClick: () -> Unit) {
    androidx.compose.material3.Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3A2A00), contentColor = Gold),
    ) { Text(text, fontWeight = FontWeight.Bold) }
}
