package com.rewardking.app.config

/** All tunable numbers live here. AdMob IDs live in res/values/ad_config.xml. */
object AppConfig {
    /** Keep true while using Google's test ad IDs. Set false only after adding real IDs. */
    const val TEST_MODE = true

    // Rewards (demo coins)
    const val COINS_PER_REWARDED_AD = 10
    const val LOGIN_BONUS = 5
    const val CHECKIN_BASE = 10
    const val CHECKIN_STREAK_STEP = 2
    const val CHECKIN_STREAK_MAX = 7

    // Ad frequency limits (AdMob policy friendly)
    const val MAX_REWARDED_PER_DAY = 30
    const val REWARDED_COOLDOWN_MS = 30_000L
    const val INTERSTITIAL_MIN_INTERVAL_MS = 180_000L

    // Lucky wheel
    const val DAILY_SPIN_LIMIT = 3
    val WHEEL_REWARDS = listOf(5, 10, 15, 20, 25, 50, 100)
    /** Relative chances matching WHEEL_REWARDS order (demo). */
    val WHEEL_WEIGHTS = listOf(30, 25, 18, 12, 8, 5, 2)

    const val APP_VERSION = "1.0.0"
}

data class WithdrawPackage(val coins: Int, val pkr: Int)

/** DEMO conversion rates only. No real payment is made by this app. */
val WITHDRAW_PACKAGES = listOf(
    WithdrawPackage(1000, 100),
    WithdrawPackage(2000, 220),
    WithdrawPackage(3000, 350),
    WithdrawPackage(4000, 500),
    WithdrawPackage(5000, 650),
    WithdrawPackage(6000, 800),
    WithdrawPackage(8000, 1100),
    WithdrawPackage(10000, 1400),
)

data class TaskDef(val id: String, val title: String, val desc: String, val reward: Int)

val DAILY_TASKS = listOf(
    TaskDef("checkin", "Daily Check-in", "Check in once today", 10),
    TaskDef("watch_ad", "Watch an Ad", "Watch one rewarded ad", 15),
    TaskDef("visit_wheel", "Visit Lucky Wheel", "Open the Lucky Wheel screen", 5),
    TaskDef("challenge", "Daily Challenge", "Solve today's maths question", 20),
    TaskDef("open_app", "Open App", "Open Reward King today", 5),
)
